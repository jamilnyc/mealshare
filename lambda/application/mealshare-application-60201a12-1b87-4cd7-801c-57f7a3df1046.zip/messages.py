"""
messages.py

Class that handles all interactions with the mealshare_messages table.
"""

import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key
import time
from decimal import Decimal

class MealShareMessages:
    TABLE_NAME = 'mealshare_messages'
    REGION = 'us-east-1'

    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb', region_name=self.REGION)
        self.table = self.dynamodb.Table(self.TABLE_NAME)

    def get_messages_by_group(self, group_id, timestamp=None, limit=25):
        expression = Key('group_id').eq(group_id)
        if timestamp is not None and int(timestamp) > 0:
            Key('group_id').eq(group_id) & Key('message_timestamp').eq(int(timestamp))
        try:
            response = self.table.query(
                KeyConditionExpression=expression,
                ScanIndexForward=False,
                Limit=limit
            )

            return response['Items']
        except ClientError as e:
            print('Error reading messages for group {}'.format(group_id))
            print(e.response['Error']['Message'])

        return []

    def add_message_to_group(self, group_id, user_id, message_body):
        now = time.time()
        now = Decimal(str(now))
        item = {
            'group_id': group_id,
            'user_id': user_id,
            'message_body': message_body,
            'message_timestamp': now
        }

        response = self.table.put_item(
            Item=item
        )

        if 'ResponseMetadata' in response:
            if 'HTTPStatusCode' in response['ResponseMetadata']:
                if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    return True
        return False
