"""
groups.py

Class for interacting with the mealshare_groups table.
"""

import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key
import time
from datetime import datetime, timedelta

class MealShareGroups:
    GROUP_TABLE_NAME = 'mealshare_groups'
    MEMBERSHIP_TABLE_NAME = 'mealshare_group_membership'
    EVENTS_TABLE_NAME = 'mealshare_events'

    REGION = 'us-east-1'
    SECONDARY_INDEX = 'user_id-group_id-index'
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb', region_name=self.REGION)
        self.group_table = self.dynamodb.Table(self.GROUP_TABLE_NAME)
        self.membership_table = self.dynamodb.Table(self.MEMBERSHIP_TABLE_NAME)
        self.events_table = self.dynamodb.Table(self.EVENTS_TABLE_NAME)
    
    def get_all_groups(self):
        try:
            response = self.group_table.scan()
            return response['Items']
        except ClientError as e:
            print('ERROR retrieving all groups')
            print(e.response['Error']['Message'])

    def get_members_by_group(self, group_id):
        members_ids = []
        expression = Key('group_id').eq(group_id)
        try:
            response = self.membership_table.query(
                KeyConditionExpression=expression
            )

            for i in response['Items']:
                members_ids.append(i['user_id'])
                
            while 'LastEvaluatedKey' in response:
                response = self.membership_table.query(
                    KeyConditionExpression=expression,
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                for i in response['Items']:
                    members_ids.append(i['user_id'])
        except ClientError as e:
            print('Error get users in group {}'.format(group_id))
            print(e.response['Error']['Message'])

        return members_ids

    def get_groups_by_user_id(self, user_id):
        group_ids = []
        expression = Key('user_id').eq(user_id)
        try:
            response = self.membership_table.query(
                KeyConditionExpression=expression,
                IndexName=self.SECONDARY_INDEX
            )
            for item in response['Items']:
                group_ids.append(item['group_id'])
            
            # Pagination
            while 'LastEvaluatedKey' in response:
                response = self.membership_table.query(
                    KeyConditionExpression=expression,
                    IndexName=self.SECONDARY_INDEX,
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                for item in response['Items']:
                    group_ids.append(item['group_id'])

        except ClientError as e:
            print('Error getting groups for user {}'.format(user_id))
            print(e.response['Error']['Message'])

        return group_ids

    def is_user_in_group(self, user_id, group_id):
        expression = Key('group_id').eq(group_id) & Key('user_id').eq(user_id)
        try:
            response = self.membership_table.query(
                KeyConditionExpression=expression
            )
            if len(response['Items']) > 0:
                return True

        except ClientError as e:
            print('Error finding if {} is in group {}'.format(user_id, group_id))
            print(e.response['Error'])

        return False

    def create_group(self, group_name):
        group_id = str(time.time()).split('.')[0]
        item = {
            'group_id': group_id,
            'group_name': group_name
        }
        response = self.group_table.put_item(Item=item)

        if 'ResponseMetadata' in response:
            if 'HTTPStatusCode' in response['ResponseMetadata']:
                if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    return group_id
        return None

    def add_user_to_group(self, user_id, group_id):
        item = {
            'group_id': group_id,
            'user_id': user_id
        }
        print(item)

        response = self.membership_table.put_item(Item=item)
        if 'ResponseMetadata' in response:
            if 'HTTPStatusCode' in response['ResponseMetadata']:
                if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    return True
        return False
        
    def create_event(self, group_id, timestamp, location, recipe_name=None, event_name=None):
        # validate timestamp
        if not isinstance(timestamp, int) or timestamp <= 0:
            # set it to one week from now
            days = 7
            one_week_from_now = datetime.now() + timedelta(days)
            timestamp = int( datetime.timestamp(one_week_from_now) )

        if not event_name:
            event_name = 'Event {}-{}'.format(group_id, timestamp)

        if not recipe_name:
            recipe_name = 'None'

        item = {
            'group_id': group_id,
            'event_timestamp': timestamp,
            'location': location,
            'recipe_name': recipe_name,
            'event_name': event_name
        }

        response = self.events_table.put_item(Item=item)
        if 'ResponseMetadata' in response:
            if 'HTTPStatusCode' in response['ResponseMetadata']:
                if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    return event_name

        return None

    def get_events(self, group_id, limit=10):
        expression = Key('group_id').eq(group_id)
        events = []
        try:
            response = self.events_table.query(
                KeyConditionExpression=expression,
                ScanIndexForward=False,
                Limit=limit
            )
            for i in response['Items']:
                event = {
                    'location': i['location'],
                    'recipe_name': i['recipe_name'],
                    'group_id': i['group_id'],
                    'event_name': i['event_name'],
                    'event_timestamp': int(i['event_timestamp'])
                }
                events.append(event)
                
            while 'LastEvaluatedKey' in response:
                # Already hit the limit, no more pagination necessary
                if len(events) >= limit:
                    break

                response = self.events_table.query(
                    KeyConditionExpression=expression,
                    ScanIndexForward=False,
                    ExclusiveStartKey=response['LastEvaluatedKey'],
                    Limit=limit
                )
                for i in response['Items']:
                    event = {
                        'location': i['location'],
                        'recipe_name': i['recipe_name'],
                        'group_id': i['group_id'],
                        'event_name': i['event_name'],
                        'event_timestamp': int(i['event_timestamp'])
                    }
                    events.append(event)
                    if len(events) >= limit:
                        break # Break for loop

        except ClientError as e:
            print('Error reading messages for group {}'.format(group_id))
            print(e.response['Error'])

        return events
        
    def get_events_by_user_id(self, user_id):
        group_ids = self.get_groups_by_user_id(user_id)
        events = []
        for group_id in group_ids:
            group_events = self.get_events(group_id, 100)
            events.extend(group_events)

        # sort by timestamp
        sorted_events = sorted(events, key=lambda k: k['event_timestamp'], reverse=True)
        return sorted_events