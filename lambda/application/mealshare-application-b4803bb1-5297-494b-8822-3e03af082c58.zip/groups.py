"""
groups.py

Class for interacting with the mealshare_groups table.
"""

import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key
import time

class MealShareGroups:
    GROUP_TABLE_NAME = 'mealshare_groups'
    MEMBERSHIP_TABLE_NAME = 'mealshare_group_membership'
    REGION = 'us-east-1'
    SECONDARY_INDEX = 'user_id-group_id-index'
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb', region_name=self.REGION)
        self.group_table = self.dynamodb.Table(self.GROUP_TABLE_NAME)
        self.membership_table = self.dynamodb.Table(self.MEMBERSHIP_TABLE_NAME)
    
    def get_all_groups(self):
        try:
            response = self.group_table.scan()
            return response['Items']
        except ClientError as e:
            print('ERROR retrieving all groups')
            print(e.response['Error']['Message'])

    def get_members_by_group(self, group_id):
        members_ids = []
        expression = Key('group_id').eq(group_id)
        try:
            response = self.membership_table.query(
                KeyConditionExpression=expression
            )

            for i in response['Items']:
                members_ids.append(i['user_id'])
        except ClientError as e:
            print('Error get users in group {}'.format(group_id))
            print(e.response['Error']['Message'])

        return members_ids

    def get_groups_by_user_id(self, user_id):
        group_ids = []
        expression = Key('user_id').eq(user_id)
        try:
            response = self.membership_table.query(
                KeyConditionExpression=expression,
                IndexName=self.SECONDARY_INDEX
            )
            for item in response['Items']:
                group_ids.append(item['group_id'])
        except ClientError as e:
            print('Error getting groups for user {}'.format(user_id))
            print(e.response['Error']['Message'])

        return group_ids

    def is_user_in_group(self, user_id, group_id):
        expression = Key('group_id').eq(group_id) & Key('user_id').eq(user_id)
        try:
            response = self.membership_table.query(
                KeyConditionExpression=expression
            )
            if len(response['Items']) > 0:
                return True

        except ClientError as e:
            print('Error finding if {} is in group {}'.format(user_id, group_id))
            print(e.response['Error'])

        return False

    def create_group(self, group_name):
        group_id = str(time.time()).split('.')[0]
        item = {
            'group_id': group_id,
            'group_name': group_name
        }
        response = self.group_table.put_item(Item=item)

        if 'ResponseMetadata' in response:
            if 'HTTPStatusCode' in response['ResponseMetadata']:
                if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    return group_id
        return None

    def add_user_to_group(self, user_id, group_id):
        item = {
            'group_id': group_id,
            'user_id': user_id
        }
        print(item)

        response = self.membership_table.put_item(Item=item)
        if 'ResponseMetadata' in response:
            if 'HTTPStatusCode' in response['ResponseMetadata']:
                if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    return True
        return False